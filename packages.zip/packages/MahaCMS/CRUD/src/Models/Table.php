<?php

namespace MahaCMS\CRUD\Models;

use Illuminate\Database\Eloquent\Model;

class Table extends Model
{
    //
}
