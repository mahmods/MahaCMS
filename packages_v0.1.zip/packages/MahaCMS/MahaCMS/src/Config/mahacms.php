<?php
return [
    'superadmins' => [
        'mahmod@gmail.com',
    ],
];